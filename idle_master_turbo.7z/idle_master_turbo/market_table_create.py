
sessionID = "" 
steamLoginSecure = ""

#2025-12-13-3

# create table of the items you put on steam marketpace, with info on highest buy, and lowest sell, and difference to your offer.
# login to steamcommunity, press shift-f9, copy paste here sessionID and steamLoginSecure 
# see idle.py for more info
# run like this: python script.py
# use this to see the difference between 'Buyer Pays (Cents)', and 'Highest Bid (Cents)'. if it is 1 cent, you should relist on the lower price.
# also if last column is 1 or more, you should relist your item.
# dont forget to set autoload in steamcommunity to 5 min, using tab reloader plugin
# When selling, sell 1c less then the best offer, if there is matching offer near use that value. It will be matched and sold instantly.
# Pending means, it was matched, but not yet paid for? I think.
# Badges are used to increase your steam level. mostly unintersting
# Booster packs are used to create more cards. you don't have to have cards to create booster packs
# if the card says 'not marketable' create gems from it. Pack them in 1000 and sell on the market.
# Price for foil cards is usually around 40cents (eurocents)
# Sell muti cards per game: https://steamcommunity.com/id/username/badges/ click on sell cards. price might not be correct, as when you click on card and observe it in the detail market page
# View your listing on market: https://steamcommunity.com/market
# Wallet: https://store.steampowered.com/steamaccount/addfunds/
# Profile: https://steamcommunity.com/id/username/
# Inventory: https://steamcommunity.com/id/username/inventory

#roadmap:
#1. print(f"https://steamcommunity.com/market/listings/{appid}/{encoded_hash_name}"), example: https://steamcommunity.com/market/listings/753/261700-Stil
#2. search for: Market_LoadOrderSpread, result: Market_LoadOrderSpread( 2232535 );	// initial load
#3. use this: https://steamcommunity.com/market/itemordershistogram?country=BA&language=english&currency=3&item_nameid=2232535&two_factor=0&norender=1


#--- USER CONFIGURATION ---
#USE NUMBER 0 GET ALL
v_number_of_scraping_items = 0

v_print_items_to_console_after_scraping = 0

#country: US, DE, GB ...
v_country = "BA"
#currency: USD-1,GBP-2,EUR-3 ...
v_currency = 3


# 1=Enable color highlighting, 0=Disable color highlighting
v_use_color_in_html = 1
# --------------------------------------

v_sleep_time = 0.5

v_save_json_all = 0
v_save_json_detail = 0

# --- REQUIRED IMPORTS ---
import requests
import json
import time
from bs4 import BeautifulSoup 
import re
import os
from urllib.parse import quote
import sys


# --- CRITICAL VALIDATION AND CONFIG DISPLAY ---
if sessionID == "" or steamLoginSecure == "":
	print("FATAL ERROR: Missing Steam cookie values in script configuration.")
	input("Press Enter to exit ...")
	sys.exit()


ITEMS_PER_PAGE = 100
MAX_PAGES = 50
file_json_all = "m_steam_my_listings_all.json"
file_json_detail = "m_steam_individual_price_and_lowest_sell_highest_buy.json"
file_html_all = "m_steam_report.html"

# ----------------------

cookies = {
	"sessionid": sessionID,
	"steamLoginSecure": steamLoginSecure
}

headers = {
	"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Referer": "https://steamcommunity.com/market/"
}

BASE_URL = "https://steamcommunity.com/market/mylistings/"

# --- Utility Functions (Unchanged) ---

def convert_currency_to_cents(currency_string):
	"""
	Converts a Steam formatted currency string (e.g., "0,07€" or "(0,07€)") to an integer in cents/subunits.
	Returns None if conversion fails.
	"""
	if not currency_string:
		return None
	try:
		is_negative = currency_string.startswith('-')
		clean_string = currency_string.replace('-', '')
		clean_string = clean_string.replace('(', '')
		
		CURRENCY_SYMBOLS = ['€', '$', '£', '¥', '₹']
		for symbol in CURRENCY_SYMBOLS:
			clean_string = clean_string.replace(symbol, '')
			
		clean_string = clean_string.replace(',', '.')
			
		clean_string = clean_string.replace(')', '').strip() # Final .strip() for any leading/trailing whitespace
		
		if not clean_string:
			return None
			
		cents = int(float(clean_string) * 100)
		return -cents if is_negative else cents
	except ValueError:
		return None

def calculate_net_price_cents(buyer_pays_cents):
	"""
	Calculates the seller receives amount based on standard Steam market fees.
	This is a fallback calculation for when scraping the net price fails.
	"""
	if buyer_pays_cents is None or buyer_pays_cents <= 0:
		return None
	
	# 5% Valve Fee, minimum 1 cent
	valve_fee = max(1, int(buyer_pays_cents * 0.05)) 
	
	# 10% Game Developer Fee, minimum 1 cent (varies per game, but 10% is standard max)
	game_fee = max(1, int(buyer_pays_cents * 0.10)) 
	
	total_fee = valve_fee + game_fee
	
	# Total minimum fee is 2 cents
	if buyer_pays_cents < 3:
		return 0
	
	if total_fee >= buyer_pays_cents:
		return max(0, buyer_pays_cents - 2)
	
	return buyer_pays_cents - total_fee

# --- Part 1: Download and Save Market Listings (Unchanged) ---

def download_and_save_listings(cookies, headers):
	"""Downloads all active market listings and saves them to a JSON file."""
	processed_assets = []
	current_start = 0
	total_listings = 1
	pages_downloaded = 0

	print("Starting download and extraction of your active market listings ...")

	while current_start < total_listings and pages_downloaded < MAX_PAGES:
		params = {"start": current_start, "count": ITEMS_PER_PAGE, "norender": 1}
		print(f"Fetching page starting at listing #{current_start} ...")
		try:
			response = requests.get(BASE_URL, cookies=cookies, headers=headers, params=params)
			response.raise_for_status()
			data = response.json()
		except requests.exceptions.RequestException as e:
			print(f"An error occurred during the request: {e}")
			break
		except json.JSONDecodeError:
			print("Failed to decode JSON. Check your cookies or if the Steam API is temporarily unavailable.")
			break

		if data.get("success") and data.get("total_count") is not None:
			total_listings = data["total_count"]
			raw_listings = data.get("listings", [])
			global_assets = data.get("assets", {})

			for listing in raw_listings:
				listing_id = listing.get('listingid')
				asset_info = listing.get('asset', {})
				asset_appid = str(asset_info.get('appid'))
				asset_contextid = str(asset_info.get('contextid'))
				asset_id = str(asset_info.get('id'))
				asset_details = global_assets.get(asset_appid, {}).get(asset_contextid, {}).get(asset_id, {})
				
				if asset_details:
					processed_assets.append({
						"listingid": listing_id, "appid": asset_appid, "id": asset_id,
						"name": asset_details.get('name'), "type": asset_details.get('type'),
						"market_name": asset_details.get('market_name'), 
						"market_hash_name": asset_details.get('market_hash_name'),
						"unowned_context_id": asset_contextid
					})
				else:
					print(f"Warning: Could not find asset details for listing ID {listing_id}")

			current_start += len(raw_listings)
			pages_downloaded += 1
			print(f"Fetched {len(raw_listings)} listings. Total collected: {len(processed_assets)} / {total_listings}")
			time.sleep(v_sleep_time) 
		else:
			print("Failed to fetch listings or received an unsuccessful response.")
			break

	print("\n--- Download Complete ---")
	if processed_assets:
		if v_save_json_all==1:
			with open(file_json_all, "w", encoding="utf-8") as f:
				json.dump(processed_assets, f, indent=4)
			print(f"Data saved to {file_json_all}")
			
		return processed_assets
	return []


# --- Part 2: Scrape Single Item Price and Spread (FINAL CRASH-PROOF VERSION) ---

def scrape_single_item_price_and_spread(appid, item_hash_name, cookies, headers, counter, total):
	"""
	Fetches a single item's market page (Request 1) and the order histogram (Request 2).
	Outputs all prices and quantities in integer cents.
	"""
	# FIX: Ensure proper URL encoding for item names containing '#'
	encoded_hash_name = quote(item_hash_name, safe='') 
	ITEM_URL = f"https://steamcommunity.com/market/listings/{appid}/{encoded_hash_name}"
	
	print(f"Scraping {counter}/{total}: {item_hash_name} ...")

	list_price_cents = None
	lowest_sell_cents = None 
	highest_buy_cents = None
	seller_receives_cents = None 

	result = {
		"market_hash_name": item_hash_name,
		"listing_url": ITEM_URL,
		"item_nameid": None,
		"seller_receives_cents": None,
		"lowest_sell_order_cents": None,
		"highest_buy_order_cents": None,
		"lowest_sell_quantity": None, 
		"highest_buy_quantity": None,
		"buyer_pays_cents": None,
		"list_price_minus_highest_bid_cents": None,
		"list_price_minus_lowest_sell_cents": None 
	}

	# --- Request 1: Fetch HTML Page ---
	try:
		response = requests.get(ITEM_URL, cookies=cookies, headers=headers)
		response.raise_for_status()
		soup = BeautifulSoup(response.text, 'html.parser')
	except requests.exceptions.RequestException as e:
		result["error"] = f"Failed to fetch item page: {e}"
		return result

	# --- Extract User Listing Prices (HTML) ---
	price_container = soup.select_one('.market_listing_right_cell.market_listing_my_price .market_listing_price')
	
	if price_container:
		price_span = price_container.select_one('span[title*="price the buyer pays."]')
		if price_span:
			price_str = price_span.get_text(strip=True)
			list_price_cents = convert_currency_to_cents(price_str)
			result["buyer_pays_cents"] = list_price_cents

		receive_span = price_container.select_one('span[title*="how much you will receive."]')
		if receive_span:
			receive_str = receive_span.get_text(strip=True)
			seller_receives_cents = convert_currency_to_cents(receive_str)
			result["seller_receives_cents"] = seller_receives_cents

		if result["seller_receives_cents"] is None and list_price_cents is not None:
			  seller_receives_cents = calculate_net_price_cents(list_price_cents)
			  result["seller_receives_cents"] = seller_receives_cents
			  print(f"	INFO: Scrape failed for Seller Receives, using calculated net price: {result['seller_receives_cents']} cents.")
	else:
		print(f"Warning: User listing price block not found for {item_hash_name}. Prices will be null.") 

	# --- Extract item_nameid (HTML via Regex) ---
	script_tag = soup.find('script', string=lambda t: t and 'Market_LoadOrderSpread' in t)
	
	if script_tag:
		match = re.search(r'Market_LoadOrderSpread\s*\(\s*(\d+)\s*\)', script_tag.string)
		if match:
			item_nameid = match.group(1)
			result["item_nameid"] = item_nameid
	
	# --- Request 2: Fetch Order Histogram (API) ---
	if result["item_nameid"]:
		HISTOGRAM_URL = "https://steamcommunity.com/market/itemordershistogram"
		histogram_params = {
			"country": v_country, "currency": v_currency, "language": "english",
			"two_factor": 0, "item_nameid": result["item_nameid"], "norender": 1
		}
		
		try:
			hist_response = requests.get(HISTOGRAM_URL, headers=headers, params=histogram_params)
			hist_response.raise_for_status()
			hist_data = hist_response.json()

			if hist_data.get("success"):
				lowest_sell_raw = hist_data.get("lowest_sell_order")
				highest_buy_raw = hist_data.get("highest_buy_order")
				
				# Orders are returned as a list of dictionaries: [{'price': 'X', 'quantity': 'Y'}, ...]
				sell_orders = hist_data.get("sell_order_table", [])
				buy_orders = hist_data.get("buy_order_table", [])
				
				# 1. Extract Lowest Sell Price (Cents)
				try:
					# Lowest_sell_raw is an integer string supplied by the API
					lowest_sell_cents = int(lowest_sell_raw) if lowest_sell_raw is not None else None
					result["lowest_sell_order_cents"] = lowest_sell_cents
				except (TypeError, ValueError):
					lowest_sell_cents = None
				
				# 2. Extract Highest Buy Price (Cents)
				try:
					# Highest_buy_raw is an integer string supplied by the API
					highest_buy_cents = int(highest_buy_raw) if highest_buy_raw is not None else None
					result["highest_buy_order_cents"] = highest_buy_cents
				except (TypeError, ValueError):
					highest_buy_cents = None

				
				# 3. Extract Lowest Sell Quantity (CRASH FIX IMPLEMENTED HERE)
				if sell_orders and lowest_sell_cents is not None:
					try:
						first_sell_order = sell_orders[0]
						# Use convert_currency_to_cents to get the integer price from the table
						first_sell_price_cents = convert_currency_to_cents(first_sell_order.get('price'))
						
						# Verify the price from the table matches the API's reported lowest price
						if first_sell_price_cents == lowest_sell_cents:
							# Safely convert quantity string to integer
							result["lowest_sell_quantity"] = int(first_sell_order.get('quantity', 0))
						else:
							 # If they don't match, the data is corrupted, set quantity to None
							 result["lowest_sell_quantity"] = None 
							 
					except (KeyError, IndexError, TypeError, ValueError):
						# Catch the crash if keys are missing or conversion fails, set quantity to None
						result["lowest_sell_quantity"] = None
						print(f"	INFO: API Error retrieving sell quantity for {item_hash_name}. Setting quantity to None.")

				
				# 4. Extract Highest Buy Quantity (CRASH FIX IMPLEMENTED HERE)
				if buy_orders and highest_buy_cents is not None:
					try:
						first_buy_order = buy_orders[0]
						first_buy_price_cents = convert_currency_to_cents(first_buy_order.get('price'))
						
						if first_buy_price_cents == highest_buy_cents:
							# Safely convert quantity string to integer
							result["highest_buy_quantity"] = int(first_buy_order.get('quantity', 0))
						else:
							 result["highest_buy_quantity"] = None
							 
					except (KeyError, IndexError, TypeError, ValueError):
						# Catch the crash, set quantity to None
						result["highest_buy_quantity"] = None
						print(f"	INFO: API Error retrieving buy quantity for {item_hash_name}. Setting quantity to None.")
						
			else:
				print(f"Warning: Failed to retrieve histogram for {item_hash_name}.")

		except requests.exceptions.RequestException:
			print(f"Warning: API request error for histogram of {item_hash_name}.")
		except json.JSONDecodeError:
			print(f"Warning: Failed to decode JSON from histogram API for {item_hash_name}.")
	
	# --- Calculate Differences ---
	
	# 1. Difference (Your Offer - Highest Buy)
	if highest_buy_cents is not None and list_price_cents is not None:
		price_difference_bid = list_price_cents - highest_buy_cents
		result["list_price_minus_highest_bid_cents"] = price_difference_bid
	
	# 2. Difference (Your Offer - Lowest Sell)
	if lowest_sell_cents is not None and list_price_cents is not None:
		price_difference_sell = list_price_cents - lowest_sell_cents
		result["list_price_minus_lowest_sell_cents"] = price_difference_sell

	return result

# --- HTML Report Generation Function (Console Display Updated) ---

def create_sortable_html_report(scraped_results, filename):
	"""Generates a single HTML file with a sortable table."""
	
	if not scraped_results:
		return
	
	# Check the flag for color use
	color_styles = """
			/* Highlight row where your listing price is lower than the highest bid (Difference < 0) */
			.diff-negative-bid { background-color: #d1e7dd; font-weight: bold; } 
			/* Highlight row where your listing price is higher than the lowest market sell price (Diff > 0) */
			.diff-positive-sell { background-color: #fff3cd; } 
	""" if v_use_color_in_html == 1 else ""

	# Basic HTML and CSS for a sortable table
	html_content = f"""
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Steam Market Spread Report</title>
		<style>
			body {{ font-family: Arial, sans-serif; margin: 20px; }}
			table {{ width: 100%; border-collapse: collapse; }}
			th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
			th {{ background-color: #f2f2f2; cursor: pointer; }}
			{color_styles}
		</style>
	</head>
	<body>
		<h1>Market Report</h1>
		<table id="priceTable">
			<thead>
				<tr>
					<th onclick="sortTable(0)">Item Name</th>
					<th onclick="sortTable(1)">Your Offer</th>
					<th onclick="sortTable(2)">Highest Buy (Qty)</th>
					<th onclick="sortTable(3)">Your Offer - Highest Buy</th>
					<th onclick="sortTable(4)">Lowest Sell (Qty)</th>
					<th onclick="sortTable(5)">Your Offer - Lowest Sell</th>
				</tr>
			</thead>
			<tbody>
	"""

	for item in scraped_results:
		# Get values, defaulting to empty string for display if None
		name = item.get("market_hash_name", "")
		buyer_pays = item.get("buyer_pays_cents", "")
		
		lowest_sell_cents = item.get("lowest_sell_order_cents")
		lowest_sell_qty = item.get("lowest_sell_quantity")
		highest_buy_cents = item.get("highest_buy_order_cents")
		highest_buy_qty = item.get("highest_buy_quantity")
		
		# Format the Price (Quantity) strings for display
		
		# Highest Buy Format: Cents (Qty)
		highest_buy_display = "N/A"
		if highest_buy_cents is not None:
			 # Displays 'None' or '0' if quantity extraction failed gracefully
			 highest_buy_display = f"{highest_buy_cents} ({highest_buy_qty if highest_buy_qty is not None else 'N/A'})" 

		# Lowest Sell Format: Cents (Qty)
		lowest_sell_display = "N/A"
		if lowest_sell_cents is not None:
			 # Displays 'None' or '0' if quantity extraction failed gracefully
			 lowest_sell_display = f"{lowest_sell_cents} ({lowest_sell_qty if lowest_sell_qty is not None else 'N/A'})"


		# Differences 
		diff_bid = item.get("list_price_minus_highest_bid_cents") 
		diff_sell = item.get("list_price_minus_lowest_sell_cents") 
		
		# Determine CSS class based on the calculated differences and the color flag
		row_class = ""
		if v_use_color_in_html == 1:
			if diff_bid is not None and diff_bid < 0:
				row_class = "diff-negative-bid" # Bid is higher than listing price (GREEN)
			elif diff_sell is not None and diff_sell > 0:
				row_class = "diff-positive-sell" # Listing price is higher than lowest market sell (YELLOW)

		# The data cells now use the formatted display string but rely on the original
		# numeric cents for the data-value attribute used for sorting.
		html_content += f"""
		<tr class="{row_class}">
			<td><a href="{item.get('listing_url')}" target="_blank">{name}</a></td>
			<td data-value="{buyer_pays if buyer_pays is not None else -99999}">{buyer_pays if buyer_pays is not None else 'N/A'}</td>
			<td data-value="{highest_buy_cents if highest_buy_cents is not None else -99999}">{highest_buy_display}</td>
			<td data-value="{diff_bid if diff_bid is not None else 99999}">{diff_bid if diff_bid is not None else 'N/A'}</td>
			<td data-value="{lowest_sell_cents if lowest_sell_cents is not None else 99999}">{lowest_sell_display}</td>
			<td data-value="{diff_sell if diff_sell is not None else 99999}">{diff_sell if diff_sell is not None else 'N/A'}</td>
		</tr>
		"""

	# Close table and add JavaScript for sorting (Unchanged)
	html_content += """
			</tbody>
		</table>

		<script>
			function sortTable(n) {
				var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
				table = document.getElementById("priceTable");
				switching = true;
				dir = "asc"; 

				while (switching) {
					switching = false;
					rows = table.getElementsByTagName("TR");

					// There are 6 columns (index 0 to 5)
					for (i = 1; i < (rows.length - 1); i++) {
						shouldSwitch = false;
						x = rows[i].getElementsByTagName("TD")[n];
						y = rows[i + 1].getElementsByTagName("TD")[n];

						// Use the data-value attribute for proper numeric sorting
						var xValue = parseFloat(x.getAttribute("data-value") || x.innerHTML);
						var yValue = parseFloat(y.getAttribute("data-value") || y.innerHTML);
						
						// Fallback to text comparison if not numeric (for column 0: Item Name)
						if (isNaN(xValue) || isNaN(yValue) || n === 0) {
							xValue = x.innerHTML.toLowerCase();
							yValue = y.innerHTML.toLowerCase();
						}

						if (dir == "asc") {
							if (xValue > yValue) {
								shouldSwitch = true;
								break;
							}
						} else if (dir == "desc") {
							if (xValue < yValue) {
								shouldSwitch = true;
								break;
							}
						}
					}
					if (shouldSwitch) {
						rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
						switching = true;
						switchcount ++;
					} else {
						if (switchcount == 0 && dir == "asc") {
							dir = "desc";
							switching = true;
						}
					}
				}
			}
		</script>"""
	html_content += f"""
	<p>You will recieve: "Your Offer" - 2 cents.</p>
	<p>Report generated at: {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
	</body>
	</html>
	"""
	
	try:
		with open(filename, "w", encoding="utf-8") as f:
			f.write(html_content)
		print(f"\nSortable HTML report saved to {filename}")
	except Exception as e:
		print(f"Error saving HTML report: {e}")

# --- Main Execution Block (Unchanged) ---

if __name__ == "__main__":
	
	# 1. Download and save all active listings
	listing_data = download_and_save_listings(cookies, headers)
	
	if not listing_data:
		print("\nCould not download any listings. Cannot proceed with scraping.")
	else:
		# 2. Process the items based on v_number_of_scraping_items limit
		if v_number_of_scraping_items==0:
			list_items_to_scrape = listing_data
		else:
			list_items_to_scrape = listing_data[:v_number_of_scraping_items]

		scraped_results = []

		print(f"STARTING DETAILED SCRAPING & API CALLS FOR {len(list_items_to_scrape)} ITEMS ...")

		counter = 0
		if v_number_of_scraping_items==0:
			total = len(list_items_to_scrape)
		else:
			total = v_number_of_scraping_items
			
			
		for item in list_items_to_scrape:
			appid = item.get("appid")
			item_hash_name = item.get("market_hash_name")
			
			counter = counter + 1
			
			if appid and item_hash_name:
				scrape_result = scrape_single_item_price_and_spread(appid, item_hash_name, cookies, headers, counter, total)
				scraped_results.append(scrape_result)
				time.sleep(v_sleep_time) # Delay between scraping individual pages
			else:
				print(f"Skipping item due to missing appid or market_hash_name: {item.get('name')}")
		
		# 3. Save JSON and generate HTML report
		
		# --- Final Display (INTEGER CENTS ONLY) ---
		print("\n--- Detailed Scraping Summary (All Prices in Integer Cents) ---")
		for result in scraped_results:
			difference_bid = result.get('list_price_minus_highest_bid_cents')
			difference_sell = result.get('list_price_minus_lowest_sell_cents')
			
			action_needed = ""
			
			if difference_bid is not None and difference_bid < 0:
				 action_needed = " (INSTANT SALE AVAILABLE!)"
			elif difference_bid is not None and difference_bid == 0:
				 action_needed = " (PRICED AT HIGHEST BID)"

			if v_print_items_to_console_after_scraping == 1:
				print(f"* Item: {result['market_hash_name']}")
				print(f" - Your Offer: {result['buyer_pays_cents']}")
				
				# Console output for Highest Buy
				highest_buy_str = f"{result['highest_buy_order_cents']}"
				if result['highest_buy_quantity'] is not None:
					highest_buy_str += f" ({result['highest_buy_quantity']} items)"
				print(f" - Highest Buy (Qty): {highest_buy_str}")
				
				print(f" - Your Offer - Highest Buy: {difference_bid} {action_needed}")

				# Console output for Lowest Sell
				lowest_sell_str = f"{result['lowest_sell_order_cents']}"
				if result['lowest_sell_quantity'] is not None:
					lowest_sell_str += f" ({result['lowest_sell_quantity']} items)"
				print(f" - Lowest Sell (Qty): {lowest_sell_str}")
				
				print(f" - Your Offer - Lowest Sell: {difference_sell}")
				print("-" * 40)
			

		# Save the detailed scraped data to a JSON file
		if scraped_results:
			if v_save_json_detail==1:
				with open(file_json_detail, "w", encoding="utf-8") as f:
					json.dump(scraped_results, f, indent=4)
				print(f"\nDetailed price and spread data saved to {file_json_detail}")
			
			# Generate the sortable HTML report
			create_sortable_html_report(scraped_results, file_html_all)