
sessionID = "" 
steamLoginSecure = ""

#2025-12-18-1

#based on linux-idle-master
#python required, works in linux and windows
#install needed plugins for python:
#pip install requests beautifulsoup4

#SETUP:
#Log in to https://steamcommunity.com/ on a web browser of your choice
#Search your cookies for steamcommunity.com *(Firefox user can use Shift-F9 to inspect cookie data)*
#Cookies are valid for 24 hours.
#Add values to the top of this file:
#copy-paste 'sessionid' content *(an alpha-numerical code)* from cookie data to the first field
#Copy-paste 'steamLoginSecure' content *(really long alpha-numerical code)* from cookie data into the second field

#NOTE this cookie data will expire after some time, use tab reloader (5 min) or some other firefox plugin
#Do not use vac games while idling (cs2...)

#login in steam app.
#start this script from command line with: python scriptname.py
#you will probably see games starting in steam
#DO NOT DELETE start_game_in_background.py

#powershell "[console]::beep(500, 100)"
#aplay file.wav
#7zip a -mx9 idle_master_turbo.7z idle_master_turbo/*

# To see which games have card drops, either run and stop idle_master, 
# or use 'augumented steam' addon for firefox, go to my profile/badges, select 'display ony games with cards drops remaining'
# https://store.steampowered.com/points/shop/ buy season badges to increase steam level. increased level > chances of booster pack.
# buy the highest 'season badge' one you can afford with points

#Steam Booster Packs are random drops containing 3 trading cards for a specific game you own, earned by playing games with card drops; 
#your Steam Level boosts your chance, and you can also craft them with gems or buy/trade for them on the Community Market. They help you 
#complete card sets to craft badges, which level up your Steam profile, and are essential for getting cards beyond your free play drops. 
# How to Get Them:
#Play Games: Earn drops by playing games that support Steam Trading Cards (you get a limited number of card drops per game).
#Boost Your Level: For every 10 Steam Levels you gain (up to level 100), your chance to receive a booster pack increases by 20%.
#Craft with Gems: Turn unwanted cards into gems and use the Booster Pack Creator in your inventory to craft packs for specific games.
#Community Market: Buy booster packs directly from other users on the Steam Market.
#Trading: Trade with other players for packs. 

#To qualify for free Steam booster packs, you must earn all available trading card drops for a specific game, own that game, 
#have a Steam account level (higher levels increase odds), and log into Steam at least weekly, essentially entering a 
#lottery where new packs drop when other users craft badges for that game. You can increase your chances by 
#owning more games with card drops and leveling up your Steam profile

#see your steam points (click on any badge), and you can buy season badges here: https://store.steampowered.com/points/howitworks

# Idling Limits
MAX_IDLE_GAMES = 32		  # 32, Maximum number of games to idle concurrently
LIST_UPDATE_INTERVAL = 120  # 120, Time in seconds to re-scrape the card drop list

# Turbo Mode = Restart games every x seconds
# Standard Mode = 20-minute cycle
TURBO_MODE = 1		# 1, 1=ON, 0=OFF 
TURBO_GAME_PLAY_TIME = 1		# 1, Time in seconds to keep game open, if TURBO_MODE is ON

# Standard Idling Time (Used if TURBO_MODE is OFF)
STANDARD_IDLE_TIME = 1200   # 20 minutes (1200 seconds)

#wait x seconds after you closed game(s)
v_wait_seconds_after_you_closed_games = 1

v_print_restart = 0

v_print_active_slots_number = 0

app_name_cache = {}
CACHE_FILE = "badges_cache.txt"

#don't play at the same time collecting cards for this
VAC_BLACKLIST = []
#VAC_BLACKLIST = [
#	730,	# Counter-Strike 2 (CS:GO)
#	570,	# Dota 2
#	440,	# Team Fortress 2
#	240,	# Counter-Strike: Source
#	4000,   # Garry's Mod
#	550,	# Left 4 Dead 2
#	220,	# Half-Life 2
#	252490, # Rust
#]

# ===================================================================
# SCRIPT EXECUTION 
# ===================================================================

import requests
import bs4
import time
import re
import subprocess
import sys
import os
import json
from multiprocessing import Pool, current_process, Manager

# Python Binary Selection
# all OSes use python, right? without 3 at the end ...
python_bin="python"
#python_bin = "python3" if sys.platform.startswith('linux') else "python"

try:
	subprocess.call([python_bin, "--version"], stdout = subprocess.DEVNULL, stderr=subprocess.DEVNULL)
except:
	print(f"FATAL ERROR: Python binary '{python_bin}' not found.")
	input("Press Enter to exit...")
	sys.exit()

# --- CRITICAL VALIDATION AND CONFIG DISPLAY ---
if sessionID == "" or steamLoginSecure == "":
	print("FATAL ERROR: Missing Steam cookie values in script configuration.")
	input("Press Enter to exit...")
	sys.exit()



# The script relies on 'start_game_in_background.py' being in the same directory.
if not os.path.exists("start_game_in_background.py"):
	print("FATAL ERROR: The required helper script 'start_game_in_background.py' was not found in the current directory.")
	print("Please ensure 'start_game_in_background.py' is present.")
	input("Press Enter to exit...")
	sys.exit()



# Directory & Steam Profile URL Setup
os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
myProfileURL = "https://steamcommunity.com/profiles/" + steamLoginSecure[:17]



print("Authentication: Cookies are SET.")
print(f"MAX_IDLE_GAMES: {MAX_IDLE_GAMES}")
print(f"TURBO_MODE: {'ON' if TURBO_MODE else 'OFF'} (Value: {TURBO_MODE})")
print(f"TURBO_GAME_PLAY_TIME: {TURBO_GAME_PLAY_TIME} seconds")
print(f"LIST_UPDATE_INTERVAL: {LIST_UPDATE_INTERVAL} seconds")
#print("steam should be running")
print("Python binary:", python_bin)
print("You should probably set 'Steam user' status to invisible (in Friends menu), but not offline")
print("Press CTRL+Z or CTRL+C to stop")

# ===================================================================
# UTILITY FUNCTIONS 
# ===================================================================

def load_app_cache():
	cache = {}
	if os.path.exists(CACHE_FILE):
		try:
			with open(CACHE_FILE, 'r', encoding='utf-8') as f:
				for line in f:
					line = line.strip()
					if '\t' in line:
						appid, name = line.split('\t', 1)
						cache[int(appid)] = name
		except:
			pass
	return cache

def save_app_cache(cache):
	try:
		with open(CACHE_FILE, 'w', encoding='utf-8') as f:
			for appid, name in cache.items():
				# Clean name: remove accidental tabs/newlines to keep TSV file valid
				clean_name = name.replace('\t', ' ').replace('\n', '')
				f.write(f"{appid}\t{clean_name}\n")
	except:
		pass



def fn_close():
	# --- ADDED: Forceful Termination of Previous Sessions ---
	if sys.platform.startswith('linux') or sys.platform == 'darwin':
		print("INFO: Attempting to forcefully terminate any lingering 'start_game_in_background.py' processes...")
		# WARNING: This uses SIGKILL (-9), which is aggressive but ensures cleanup.
		os.system('kill -9 $(pgrep -f "start_game_in_background.py") 2>/dev/null')
	# -----------------------------------------------------


fn_close()



# ===================================================================
# STEAM CHECK & LAUNCH UTILITY
# ===================================================================

def fn_ensure_steam_running():
	"""Checks for and launches the Steam client."""
	print(f"\nSTATUS: Checking if Steam client is running...")
	
	steam_is_running = False
	
	if sys.platform.startswith('win'):
		# Windows: Check for 'steam.exe'
		try:
			# Use 'tasklist' command to check for the process
			output = subprocess.check_output('tasklist /FI "IMAGENAME eq steam.exe"', shell=True).decode()
			if "steam.exe" in output:
				steam_is_running = True
		except:
			pass # tasklist might fail, assume not running

		if not steam_is_running:
			print("INFO: Steam is NOT running. Attempting to launch Steam...")
			try:
				# Use 'start' command to launch the Steam client
				subprocess.Popen('start steam://open/main', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
				print("INFO: Waiting 10 seconds for Steam to initialize...")
				time.sleep(10)
			except Exception as e:
				print(f"FATAL ERROR: Failed to launch Steam on Windows. Error: {e}")
				sys.exit(1)
		else:
			print("INFO: Steam is already running.")
			
	elif sys.platform.startswith('linux') or sys.platform == 'darwin':
		# Linux/macOS: Check for 'steam' process
		try:
			# Use 'pgrep' command to check for the process, use [s] so it is not matching itself when searching :)
			output = subprocess.check_output('pgrep -f "[s]team" || true', shell=True).decode()
			if output.strip():
				steam_is_running = True
		except:
			pass
			
		if not steam_is_running:
			print("INFO: Steam is NOT running. Attempting to launch Steam...")
			try:
				# Use 'steam' command to launch the client
				subprocess.Popen('steam', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
				print("INFO: Waiting 10 seconds for Steam to initialize...")
				time.sleep(10)
			except Exception as e:
				print(f"FATAL ERROR: Failed to launch Steam on Linux/macOS. Error: {e}")
				sys.exit(1)
		else:
			print("INFO: Steam is already running.")
			
	else:
		# Other OS (e.g., BSD)
		print("WARNING: OS not explicitly supported for automatic Steam launch. Assuming Steam is ready.")

# ===================================================================


def generate_cookies():
	try:
		return dict(sessionid = sessionID, steamLoginSecure = steamLoginSecure, Steam_Language = "english")
	except:
		print("FATAL ERROR: Unable to set cookies.")
		input("Press Enter to exit...")
		sys.exit()

def cookie_test(cookies):
	try:
		r = requests.get(myProfileURL + "/badges/", cookies = cookies)
		badgePageData = bs4.BeautifulSoup(r.text, "html.parser")
		return not badgePageData.find("a", {"class": "user_avatar"})
	except:
		return True

def get_app_name(appID):
	try:
		api = requests.get("https://store.steampowered.com/api/appdetails/?appids=" + str(appID) + "&filters=basic")
		apiData = json.loads(api.text)
		return apiData[str(appID)]["data"]["name"]
	except:
		return "App " + str(appID)

# ===================================================================
# CORE IDLING FUNCTION
# ===================================================================
def worker_idle_process(appID, appName, is_short_cycle, running_app_ids, active_max):
	"""Function run by the multiprocessing pool to idle a single game."""
	thread_name = f"[{current_process().name}]"
	
	idle_time = TURBO_GAME_PLAY_TIME if is_short_cycle else STANDARD_IDLE_TIME
	#print(f"																										", end='\r', file=sys.stderr)
			#[SpawnPoolWorker-20] MODE: SHORT CYCLE (5s) -> RUNNING Defy Gravity E...
	# Display mode and start time
	if is_short_cycle:
		# NOTE: Using sys.stderr here to avoid conflicts if stdout is redirected
		print(f"MODE: TURBO ({idle_time}s) {active_max} SLOTS {thread_name.ljust(19, ' ')} -> RUNNING {appName[:30]}...                          ", end='\r', file=sys.stderr)
	else:
		print(f"MODE: STANDARD ({idle_time/60:.0f}m) {active_max} SLOTS {thread_name.ljust(19, ' ')} -> RUNNING {appName[:30]}...                          ", end='\r', file=sys.stderr)
	
	try:
		# Launch start_game_in_background.py
		processIdle = subprocess.Popen([python_bin, "start_game_in_background.py", str(appID)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
		
		time.sleep(idle_time)
		
		processIdle.terminate()
		processIdle.wait(timeout=1)
		#its still running
		if processIdle.poll() is None:
			try:
				# It's still running, so now we wait
				processIdle.wait(timeout=4)
				pass
			except subprocess.TimeoutExpired:
				# Handle the case where it still won't close
				processIdle.kill()
				#print("xxstill running, closed at second")
		else:
			pass
			#print("xxclosed at first")


		# Display termination message
		if is_short_cycle:
			if v_print_restart==1:
				print(f"{thread_name} RESTART: Finished {appName}. Slot free for re-queue.	  ", file=sys.stderr)
		else:
			if v_print_restart==1:
				print(f"{thread_name} FINISHED: Idle session complete for {appName}.			", file=sys.stderr)
			
	except:
		# On error, clear the line and print an error message
		print(f"{thread_name} ERROR: Failed to run or terminate {appName}.					   ", file=sys.stderr)
		
	try:
		if appID in running_app_ids:
			#print("xxremoving ids")
			running_app_ids.remove(appID)
	except:
		pass

# ===================================================================
# LIST GATHERING FUNCTION
# ===================================================================
def get_games_to_idle(cookies):
	"""Fetches the list of games with card drops remaining, filtering VAC games."""
	
	print("STATUS: Checking Steam for remaining card drops...")
	
	if cookie_test(cookies):
		print(f"{time.ctime()}: FATAL ERROR: Cookie session expired or Steam is down. Exiting.")
		sys.exit(1)

	try:
		r = requests.get(myProfileURL + "/badges/", cookies = cookies)
	except:
		return []

	try:
		badgesLeft = []
		badgePageData = bs4.BeautifulSoup(r.text, "html.parser")
		badgeSet = badgePageData.find_all("div", {"class": "badge_title_stats"})
	except:
		return []

	# Handle multiple pages
	try:
		badgePages = 1
		pagelinks = badgePageData.find_all("a", {"class": "pagelink"})
		if pagelinks:
			badgePages = int(pagelinks[-1].text)
		
		currentpage = 2
		while currentpage <= badgePages:
			r = requests.get(myProfileURL + "/badges/?p=" + str(currentpage), cookies = cookies)
			badgePageData = bs4.BeautifulSoup(r.text, "html.parser")
			badgeSet += badgePageData.find_all("div", {"class": "badge_title_stats"})
			currentpage += 1
	except:
		pass
	
	#print(f"INFO: Fetching names for new badges...")
	cache_updated = False
	for badge in badgeSet:
		try:
			dropCount = badge.find_all("span", {"class": "progress_info_bold"})[0].contents[0]
			
			if "No card drops" in dropCount:
				continue
			
			dropCountInt = int(dropCount.split(" ", 1)[0])
			linkGuess = badge.find_parent().find_parent().find_parent().find_all("a")[0]["href"]
			badgeID = int(linkGuess.split("/gamecards/", 1)[1].replace("/", ""))

			if badgeID in VAC_BLACKLIST:
				continue

			
			if badgeID not in app_name_cache:
				#print(f"INFO: API request for new AppID {badgeID}...")
				print(f"INFO: Fetching name for a new badge {badgeID}...")
				app_name_cache[badgeID] = get_app_name(badgeID)
				cache_updated = True # Mark that we need to save to disk

			badgesLeft.append([badgeID, dropCountInt, 0])
		except:
			continue

	if cache_updated:
		save_app_cache(app_name_cache)
		print(f"CACHE: File {CACHE_FILE} updated.")

	return badgesLeft

# ===================================================================
# MAIN EXECUTION
# ===================================================================

if __name__ == "__main__":
	
	try:
		cookies = generate_cookies() 
	except:
		sys.exit()
	
	#check exists in the pool
	#fn_ensure_steam_running()
	
	is_short_cycle = TURBO_MODE == 1
	
	last_update_time = 0
	games_to_idle = []
	
	manager = Manager()
	running_app_ids = manager.list() 


	app_name_cache = load_app_cache()
	print(f"CACHE: Loaded {len(app_name_cache)} app names from file {CACHE_FILE}.")
	
	try:
		with Pool(processes=MAX_IDLE_GAMES) as pool:
			
			while True:
				current_time = time.time()
				
				# --- A: The 5-Minute Master List Update ---
				if current_time - last_update_time >= LIST_UPDATE_INTERVAL:

					fn_ensure_steam_running()
					
					games_to_idle = get_games_to_idle(cookies)
					last_update_time = current_time
					total_drops = sum(game[1] for game in games_to_idle)
					
					if not games_to_idle:
						print(f"{time.ctime()}: INFO: No games with card drops remaining. Checking again in {LIST_UPDATE_INTERVAL}s.")
						time.sleep(LIST_UPDATE_INTERVAL)
						continue

					print(f"{time.ctime()}: STATUS: Master list updated. {len(games_to_idle)} games with {total_drops} drops remaining.")
				
				
				# --- B: Launch Logic ---
				
				available_slots = MAX_IDLE_GAMES - len(running_app_ids)
				new_games_to_launch = []
				
				#print ("xxgetting new games id")
				for appID, drops, _ in games_to_idle:
					if appID not in running_app_ids and available_slots > 0:
						#appName = get_app_name(appID)
						appName = app_name_cache.get(appID, f"App {appID}")
						new_games_to_launch.append((appID, appName))
						available_slots -= 1
				#print ("xxdone getting new games id")

				active_slots=len(running_app_ids) + len(new_games_to_launch)
				if new_games_to_launch:
					if v_print_active_slots_number == 1:
						print(f"LAUNCHER: Launching {len(new_games_to_launch)} new session(s). Total active slots: {active_slots}/{MAX_IDLE_GAMES}.                       ")
		
				for appID, appName in new_games_to_launch:
					running_app_ids.append(appID)
					pool.apply_async(worker_idle_process, args=(appID, appName, is_short_cycle, running_app_ids, f"{active_slots}/{MAX_IDLE_GAMES}" ))
				
				# --- C: Loop Control ---
				if is_short_cycle:
					wait_time = TURBO_GAME_PLAY_TIME + 1
				else:
					wait_time = LIST_UPDATE_INTERVAL - (time.time() - last_update_time)
					if wait_time <= 0:
						wait_time = 1 

				#print("xxwaiting in main",wait_time)						
				time.sleep(wait_time)

				#print(f"\nsleep after closing apps {v_wait_seconds_after_you_closed_games} seconds...",)
				time.sleep(v_wait_seconds_after_you_closed_games)
				
	except KeyboardInterrupt:
		print(f"\n{time.ctime()}: SHUTDOWN: User interrupt detected. Terminating processes...")
		pool.terminate()
		pool.join()
		sys.exit()
	except Exception as e:
		print(f"{time.ctime()}: CRITICAL RUNTIME ERROR: {e}")
		sys.exit()

	sys.exit()