
from __future__ import print_function
import os
import sys
import platform
import time
from ctypes import CDLL

def get_steam_api():
	"""
	Loads the appropriate Steam API library (DLL/SO) based on the OS and architecture.
	Requires 'steam_api.dll' (32-bit Windows), 'steam_api64.dll' (64-bit Windows), 
	or the respective .so files (Linux) to be in the same directory.
	"""
	
	lib_path = ""

	if sys.platform.startswith('linux'):
		if platform.architecture()[0].startswith('32bit'):
			print('Loading Linux 32bit library')
			lib_path = './libsteam_api32.so'
		elif platform.architecture()[0].startswith('64bit'):
			print('Loading Linux 64bit library')
			lib_path = './libsteam_api64.so'
		else:
			print('Linux architecture not supported')
			sys.exit()

	elif sys.platform.startswith('win'):
		if platform.architecture()[0].startswith('32bit'):
			print('Loading Windows 32bit library: steam_api.dll')
			lib_path = './steam_api.dll' 
		elif platform.architecture()[0].startswith('64bit'):
			print('Loading Windows 64bit library: steam_api64.dll')
			lib_path = './steam_api64.dll'
		else:
			print('Windows architecture not supported')
			sys.exit()

	else:
		print('Operating system not supported')
		sys.exit()
	
	return CDLL(lib_path)

# -----------------------------

if __name__ == '__main__':
	if len(sys.argv) != 2:
		print("Error: Wrong number of arguments. Usage: python steam_idle_cli.py <AppID>")
		sys.exit()
		
	str_app_id = sys.argv[1]
	
	# 1. Prepare Steam Environment
	# This environment variable must be set BEFORE the Steam API is initialized.
	os.environ["SteamAppId"] = str_app_id
	
	try:
		# 2. Initialize Steam API 
		steam_api = get_steam_api()
		# The key function call that tells the Steam client that this game is running.
		steam_api.SteamAPI_Init() 
		print(f"[{time.strftime('%H:%M:%S')}] Successfully connected to Steam API. Idling App ID: {str_app_id}")
	except Exception as e:
		print(f"[{time.strftime('%H:%M:%S')}] ERROR: Couldn't initialize Steam API. Ensure DLL/SO is present.")
		# print(f"Error details: {e}") # Uncomment for debugging
		sys.exit(1)
		
	# 3. Maintain the Connection (CLI Loop)
	# The Steam client reports the game as "running" as long as this process is alive.
	# We use a 1-second sleep to prevent a tight CPU-consuming loop.
	print(f"[{time.strftime('%H:%M:%S')}] Entering 1-second sleep loop. Waiting for signal to terminate...")
	
	spinner = ['-', '\\', '|', '/']
	spinner_index = 0
	
	while True:
		try:
			# Sleep for 1 second. This is the minimum to maintain low CPU usage.
			sys.stdout.write(f'\r Idling... {spinner[spinner_index % len(spinner)]}')
			sys.stdout.flush()
			spinner_index += 1
			# Sleep for 0.1 seconds to allow smooth spinner rotation and maintain low CPU usage.
			time.sleep(0.1) 			
		except KeyboardInterrupt:
			# Allows manual exit (e.g., Ctrl+C in a terminal)
			print(f"[{time.strftime('%H:%M:%S')}] Idling process manually interrupted.")
			break
		except:
			# Catch minor errors and continue the loop
			pass 
			
	# 4. Clean Shutdown 
	try:
		steam_api.SteamAPI_Shutdown()
		print(f"[{time.strftime('%H:%M:%S')}] Steam API connection terminated.")
	except:
		pass
	
	sys.exit(0)