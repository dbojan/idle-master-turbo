

sessionID = "" 
steamLoginSecure = ""

#2025-12-05-1

#based on linux-idle-master
#python required, works in linux and windows
#install needed plugins for python:
#pip install requests beautifulsoup4


#SETUP:
#Log in to https://steamcommunity.com/ on a web browser of your choice
#Search your cookies for steamcommunity.com *(Firefox user can use Shift-F9 to inspect cookie data)*
#Cookies are valid for 24 hours.
#Add values to the top of this file:
#copy-paste 'sessionid' content *(an alpha-numerical code)* from cookie data to the first field
#Copy-paste 'steamLoginSecure' content *(really long alpha-numerical code)* from cookie data into the second field

#NOTE this cookie data will expire after some time, you will have to refresh page or relogin.

#login in steam.
#start this script from command line with: python scriptname.py
#you will probably see games starting in steam
#DO NOT DELETE run_game_helper.py

# ===================================================================
# IDLER CONFIGURATION
# -------------------------------------------------------------------

# Steam Login Cookies (Get these from your browser)


# Idling Limits
MAX_IDLE_GAMES = 32		  # Maximum number of games to idle concurrently
LIST_UPDATE_INTERVAL = 120  # Time in seconds to re-scrape the card drop list

# Short Cycle Mode (Restart games every 5 seconds)
TURBO_MODE = 1		# 1 = ON (5-second cycle) / 0 = OFF (standard 20-minute cycle)
TURBO_GAME_PLAY_TIME = 3		# Time in seconds if TURBO_MODE is 1

# Standard Idling Time (Used if TURBO_MODE = 0)
STANDARD_IDLE_TIME = 1200   # 20 minutes (1200 seconds)

v_display_restart = 0

# VAC/Blacklist
VAC_BLACKLIST = [
	730,	# Counter-Strike 2 (CS:GO)
	570,	# Dota 2
	440,	# Team Fortress 2
	240,	# Counter-Strike: Source
	4000,   # Garry's Mod
	550,	# Left 4 Dead 2
	220,	# Half-Life 2
	252490, # Rust
]

# ===================================================================
# SCRIPT EXECUTION 
# ===================================================================

import requests
import bs4
import time
import re
import subprocess
import sys
import os
import json
from multiprocessing import Pool, current_process, Manager

# Python Binary Selection
#all use python, right? without 3 at the end ...
python_bin="python"
#python_bin = "python3" if sys.platform.startswith('linux') else "python"

try:
	subprocess.call([python_bin, "--version"], stdout = subprocess.DEVNULL, stderr=subprocess.DEVNULL)
except:
	print(f"FATAL ERROR: Python binary '{python_bin}' not found.")
	input("Press Enter to exit...")
	sys.exit()

# --- CRITICAL VALIDATION AND CONFIG DISPLAY ---
if sessionID == "" or steamLoginSecure == "":
	print("FATAL ERROR: Missing Steam cookie values in script configuration.")
	input("Press Enter to exit...")
	sys.exit()



# The script relies on 'run_game_helper.py' being in the same directory.
if not os.path.exists("run_game_helper.py"):
    print("FATAL ERROR: The required helper script 'run_game_helper.py' was not found in the current directory.")
    print("Please ensure 'run_game_helper.py' is present.")
    input("Press Enter to exit...")
    sys.exit()



# Directory & Steam Profile URL Setup
os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
myProfileURL = "https://steamcommunity.com/profiles/" + steamLoginSecure[:17]



print("Authentication: Cookies are SET.")
print(f"MAX_IDLE_GAMES: {MAX_IDLE_GAMES}")
print(f"TURBO_MODE: {'ON' if TURBO_MODE else 'OFF'} (Value: {TURBO_MODE})")
print(f"TURBO_GAME_PLAY_TIME: {TURBO_GAME_PLAY_TIME} seconds")
print(f"LIST_UPDATE_INTERVAL: {LIST_UPDATE_INTERVAL} seconds")
print("steam should be running")
print("python binary:", python_bin)
print("You should probably set 'Steam user' status to invisible (in Friends menu), but not offline")
print("Press CTRL+Z or CTRL+C to stop")

# ===================================================================
# UTILITY FUNCTIONS 
# ===================================================================


def fn_close():
	# --- ADDED: Forceful Termination of Previous Sessions ---
	if sys.platform.startswith('linux') or sys.platform == 'darwin':
		print("INFO: Attempting to forcefully terminate any lingering 'run_game_helper.py' processes...")
		# WARNING: This uses SIGKILL (-9), which is aggressive but ensures cleanup.
		os.system('kill -9 $(pgrep -f "run_game_helper.py") 2>/dev/null')
	# -----------------------------------------------------


fn_close()



# ===================================================================
# STEAM CHECK & LAUNCH UTILITY
# ===================================================================

def fn_ensure_steam_running():
	"""Checks for and launches the Steam client."""
	print("STATUS: Checking if Steam client is running...")
	
	steam_is_running = False
	
	if sys.platform.startswith('win'):
		# Windows: Check for 'steam.exe'
		try:
			# Use 'tasklist' command to check for the process
			output = subprocess.check_output('tasklist /FI "IMAGENAME eq steam.exe"', shell=True).decode()
			if "steam.exe" in output:
				steam_is_running = True
		except:
			pass # tasklist might fail, assume not running

		if not steam_is_running:
			print("INFO: Steam is NOT running. Attempting to launch Steam...")
			try:
				# Use 'start' command to launch the Steam client
				subprocess.Popen('start steam://open/main', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
				print("INFO: Waiting 10 seconds for Steam to initialize...")
				time.sleep(10)
			except Exception as e:
				print(f"FATAL ERROR: Failed to launch Steam on Windows. Error: {e}")
				sys.exit(1)
		else:
			print("INFO: Steam is already running.")
			
	elif sys.platform.startswith('linux') or sys.platform == 'darwin':
		# Linux/macOS: Check for 'steam' process
		try:
			# Use 'pgrep' command to check for the process
			output = subprocess.check_output('pgrep -f "steam" || true', shell=True).decode()
			if output.strip():
				steam_is_running = True
		except:
			pass
			
		if not steam_is_running:
			print("INFO: Steam is NOT running. Attempting to launch Steam...")
			try:
				# Use 'steam' command to launch the client
				subprocess.Popen('steam', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
				print("INFO: Waiting 10 seconds for Steam to initialize...")
				time.sleep(10)
			except Exception as e:
				print(f"FATAL ERROR: Failed to launch Steam on Linux/macOS. Error: {e}")
				sys.exit(1)
		else:
			print("INFO: Steam is already running.")
			
	else:
		# Other OS (e.g., BSD)
		print("WARNING: OS not explicitly supported for automatic Steam launch. Assuming Steam is ready.")

# ===================================================================


def generate_cookies():
	try:
		return dict(sessionid = sessionID, steamLoginSecure = steamLoginSecure, Steam_Language = "english")
	except:
		print("FATAL ERROR: Unable to set cookies.")
		input("Press Enter to exit...")
		sys.exit()

def cookie_test(cookies):
	try:
		r = requests.get(myProfileURL + "/badges/", cookies = cookies)
		badgePageData = bs4.BeautifulSoup(r.text, "html.parser")
		return not badgePageData.find("a", {"class": "user_avatar"})
	except:
		return True

def get_app_name(appID):
	try:
		api = requests.get("https://store.steampowered.com/api/appdetails/?appids=" + str(appID) + "&filters=basic")
		apiData = json.loads(api.text)
		return apiData[str(appID)]["data"]["name"]
	except:
		return "App " + str(appID)

# ===================================================================
# CORE IDLING FUNCTION
# ===================================================================
def worker_idle_process(appID, appName, is_short_cycle, running_app_ids):
	"""Function run by the multiprocessing pool to idle a single game."""
	thread_name = f"[{current_process().name}]"
	
	idle_time = TURBO_GAME_PLAY_TIME if is_short_cycle else STANDARD_IDLE_TIME
	print(f"                                                                                                        ", end='\r', file=sys.stderr)
			#[SpawnPoolWorker-20] MODE: SHORT CYCLE (5s) -> RUNNING Defy Gravity E...
	# Display mode and start time
	if is_short_cycle:
		# NOTE: Using sys.stderr here to avoid conflicts if stdout is redirected
		print(f"{thread_name} MODE: SHORT CYCLE ({idle_time}s) -> RUNNING {appName[:30]}...", end='\r', file=sys.stderr)
	else:
		print(f"{thread_name} MODE: STANDARD ({idle_time/60:.0f}m) -> RUNNING {appName[:30]}...", end='\r', file=sys.stderr)
	
	try:
		# Launch run_game_helper.py
		processIdle = subprocess.Popen([python_bin, "run_game_helper.py", str(appID)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
		
		time.sleep(idle_time)
		
		processIdle.terminate()
		processIdle.wait(timeout=5)

		# Display termination message
		if is_short_cycle:
			if v_display_restart==1:
				print(f"{thread_name} RESTART: Finished {appName}. Slot free for re-queue.	  ", file=sys.stderr)
		else:
			if v_display_restart==1:
				print(f"{thread_name} FINISHED: Idle session complete for {appName}.			", file=sys.stderr)
			
	except:
		# On error, clear the line and print an error message
		print(f"{thread_name} ERROR: Failed to run or terminate {appName}.					   ", file=sys.stderr)
		
	try:
		if appID in running_app_ids:
			running_app_ids.remove(appID)
	except:
		pass

# ===================================================================
# LIST GATHERING FUNCTION
# ===================================================================
def get_games_to_idle(cookies):
	"""Fetches the list of games with card drops remaining, filtering VAC games."""
	
	print("STATUS: Checking Steam for remaining card drops...")
	
	if cookie_test(cookies):
		print("FATAL ERROR: Cookie session expired or Steam is down. Exiting.")
		sys.exit(1)

	try:
		r = requests.get(myProfileURL + "/badges/", cookies = cookies)
	except:
		return []

	try:
		badgesLeft = []
		badgePageData = bs4.BeautifulSoup(r.text, "html.parser")
		badgeSet = badgePageData.find_all("div", {"class": "badge_title_stats"})
	except:
		return []

	# Handle multiple pages
	try:
		badgePages = 1
		pagelinks = badgePageData.find_all("a", {"class": "pagelink"})
		if pagelinks:
			badgePages = int(pagelinks[-1].text)
		
		currentpage = 2
		while currentpage <= badgePages:
			r = requests.get(myProfileURL + "/badges/?p=" + str(currentpage), cookies = cookies)
			badgePageData = bs4.BeautifulSoup(r.text, "html.parser")
			badgeSet += badgePageData.find_all("div", {"class": "badge_title_stats"})
			currentpage += 1
	except:
		pass
	
	for badge in badgeSet:
		try:
			dropCount = badge.find_all("span", {"class": "progress_info_bold"})[0].contents[0]
			
			if "No card drops" in dropCount:
				continue
			
			dropCountInt = int(dropCount.split(" ", 1)[0])
			linkGuess = badge.find_parent().find_parent().find_parent().find_all("a")[0]["href"]
			badgeID = int(linkGuess.split("/gamecards/", 1)[1].replace("/", ""))

			if badgeID in VAC_BLACKLIST:
				continue
			
			badgesLeft.append([badgeID, dropCountInt, 0])
		except:
			continue

	return badgesLeft

# ===================================================================
# MAIN EXECUTION
# ===================================================================

if __name__ == "__main__":
	
	try:
		cookies = generate_cookies() 
	except:
		sys.exit()

	fn_ensure_steam_running()
	
	is_short_cycle = TURBO_MODE == 1
	
	last_update_time = 0
	games_to_idle = []
	
	manager = Manager()
	running_app_ids = manager.list() 
	
	try:
		with Pool(processes=MAX_IDLE_GAMES) as pool:
			
			while True:
				current_time = time.time()
				
				# --- A: The 5-Minute Master List Update ---
				if current_time - last_update_time >= LIST_UPDATE_INTERVAL:

					fn_ensure_steam_running()
					
					games_to_idle = get_games_to_idle(cookies)
					last_update_time = current_time
					total_drops = sum(game[1] for game in games_to_idle)
					
					if not games_to_idle:
						print(f"{time.ctime()}: INFO: No games with card drops remaining. Checking again in {LIST_UPDATE_INTERVAL}s.")
						time.sleep(LIST_UPDATE_INTERVAL)
						continue

					print(f"{time.ctime()}: STATUS: Master list updated. {len(games_to_idle)} games with {total_drops} drops remaining.")
				
				
				# --- B: Launch Logic ---
				
				available_slots = MAX_IDLE_GAMES - len(running_app_ids)
				new_games_to_launch = []
				
				for appID, drops, _ in games_to_idle:
					if appID not in running_app_ids and available_slots > 0:
						appName = get_app_name(appID)
						new_games_to_launch.append((appID, appName))
						available_slots -= 1

				if new_games_to_launch:
					print(f"LAUNCHER: Launching {len(new_games_to_launch)} new session(s). Total active slots: {len(running_app_ids) + len(new_games_to_launch)}/{MAX_IDLE_GAMES}.")
				
				for appID, appName in new_games_to_launch:
					running_app_ids.append(appID)
					pool.apply_async(worker_idle_process, 
									 args=(appID, appName, is_short_cycle, running_app_ids))
					
				
				# --- C: Loop Control ---
				if is_short_cycle:
					wait_time = TURBO_GAME_PLAY_TIME + 1
				else:
					wait_time = LIST_UPDATE_INTERVAL - (time.time() - last_update_time)
					if wait_time <= 0:
						wait_time = 1 
						
				time.sleep(wait_time)
				
	except KeyboardInterrupt:
		print("\nSHUTDOWN: User interrupt detected. Terminating processes...")
		pool.terminate()
		pool.join()
		sys.exit()
	except Exception as e:
		print(f"CRITICAL RUNTIME ERROR: {e}")
		sys.exit()

	sys.exit()